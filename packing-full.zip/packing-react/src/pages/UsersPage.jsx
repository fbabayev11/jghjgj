import { useState, useEffect } from 'react'
import { API } from '../config'

const ALL_TABS = [
  { id:'orders',    label:'Sifarişlər' },
  { id:'manual',    label:'Manual Sifarişlər' },
  { id:'allorders', label:'Bütün Sifarişlər' },
  { id:'stats',     label:'Statistika' },
  { id:'images',    label:'Şəkillər' },
  { id:'settings',  label:'API Key' },
]

const ROLE_LABEL = { admin:'Admin', worker:'İşçi' }

export default function UsersPage({ token }) {
  const [users, setUsers]     = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editUser, setEditUser] = useState(null)
  const [tabsUser, setTabsUser] = useState(null)
  const [userTabs, setUserTabs] = useState([])

  // Form
  const [email, setEmail]     = useState('')
  const [name, setName]       = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole]       = useState('worker')
  const [err, setErr]         = useState('')

  const headers = { 'Content-Type':'application/json', 'Authorization':`Bearer ${token}` }

  async function load() {
    setLoading(true)
    try {
      const r = await fetch(`${API}/users`, { headers })
      if (r.ok) setUsers(await r.json())
    } catch {}
    setLoading(false)
  }
  useEffect(() => { load() }, [])

  function openNew() {
    setEditUser(null); setEmail(''); setName(''); setPassword(''); setRole('worker')
    setErr(''); setShowForm(true)
  }
  function openEdit(u) {
    setEditUser(u); setEmail(u.email); setName(u.name); setPassword(''); setRole(u.role)
    setErr(''); setShowForm(true)
  }

  async function save() {
    if (!name || (!editUser && (!email || !password))) { setErr('Məcburi sahələri doldurun'); return }
    setErr('')
    try {
      let r
      if (editUser) {
        r = await fetch(`${API}/users/${editUser.id}`, {
          method:'PUT', headers,
          body: JSON.stringify({ name, role, ...(password ? { password } : {}) })
        })
      } else {
        r = await fetch(`${API}/users`, {
          method:'POST', headers,
          body: JSON.stringify({ email, name, password, role })
        })
      }
      const d = await r.json()
      if (!r.ok) { setErr(d.detail || 'Xəta'); return }
      setShowForm(false); load()
    } catch { setErr('Xəta baş verdi') }
  }

  async function del(id) {
    if (!confirm('Silinsin?')) return
    await fetch(`${API}/users/${id}`, { method:'DELETE', headers })
    load()
  }

  async function openTabs(u) {
    setTabsUser(u)
    const r = await fetch(`${API}/user-tabs/${u.id}`, { headers })
    const d = await r.json()
    setUserTabs(d.tabs || [])
  }

  async function saveTabs() {
    await fetch(`${API}/user-tabs/${tabsUser.id}`, {
      method:'PUT', headers,
      body: JSON.stringify({ tabs: userTabs })
    })
    setTabsUser(null)
  }

  function toggleTab(id) {
    setUserTabs(prev => prev.includes(id) ? prev.filter(x=>x!==id) : [...prev, id])
  }

  return (
    <>
      <div className="refresh-row">
        <h2>👥 İstifadəçilər</h2>
        <button className="btn btn-primary btn-sm" onClick={openNew}>+ Yeni</button>
      </div>

      {/* Yeni/Redakt formu */}
      {showForm && (
        <div style={{ background:'var(--surface)', border:'1px solid var(--border)',
          borderRadius:14, padding:20, marginBottom:16 }}>
          <div style={{ fontSize:15, fontWeight:800, marginBottom:16 }}>
            {editUser ? 'İstifadəçini Redaktə Et' : 'Yeni İstifadəçi'}
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
            <div className="field">
              <label>Ad</label>
              <input value={name} onChange={e=>setName(e.target.value)} placeholder="Adı" />
            </div>
            <div className="field">
              <label>Email</label>
              <input value={email} onChange={e=>setEmail(e.target.value)}
                placeholder="email@example.com" disabled={!!editUser}
                style={{ opacity: editUser ? .5 : 1 }} />
            </div>
            <div className="field">
              <label>{editUser ? 'Yeni Şifrə (boş qoysanız dəyişmir)' : 'Şifrə'}</label>
              <input type="password" value={password} onChange={e=>setPassword(e.target.value)}
                placeholder="••••••••" />
            </div>
            <div className="field">
              <label>Rol</label>
              <select value={role} onChange={e=>setRole(e.target.value)} style={{
                width:'100%', padding:'11px 14px', borderRadius:10, border:'1px solid var(--border)',
                background:'var(--surf2)', color:'var(--text)', fontSize:14, outline:'none',
              }}>
                <option value="admin">Admin</option>
                <option value="worker">İşçi</option>
              </select>
            </div>
          </div>
          {err && <div className="error-bar" style={{marginBottom:10}}>{err}</div>}
          <div style={{ display:'flex', gap:8 }}>
            <button className="btn btn-primary btn-sm" onClick={save}>Yadda saxla</button>
            <button className="btn btn-ghost btn-sm" onClick={()=>setShowForm(false)}>Ləğv et</button>
          </div>
        </div>
      )}

      {/* Tab icazələri */}
      {tabsUser && (
        <div style={{ background:'var(--surface)', border:'1px solid var(--border)',
          borderRadius:14, padding:20, marginBottom:16 }}>
          <div style={{ fontSize:15, fontWeight:800, marginBottom:4 }}>
            {tabsUser.name} — Tab İcazələri
          </div>
          <div style={{ fontSize:12, color:'var(--muted)', marginBottom:14 }}>
            Bu istifadəçi hansı tabları görəcək?
          </div>
          <div style={{ display:'flex', flexWrap:'wrap', gap:8, marginBottom:16 }}>
            {ALL_TABS.map(t => (
              <div key={t.id} onClick={()=>toggleTab(t.id)} style={{
                padding:'7px 14px', borderRadius:20, fontSize:13, fontWeight:600,
                cursor:'pointer', border:'1px solid', transition:'all .15s',
                background: userTabs.includes(t.id) ? 'rgba(245,166,35,.12)' : 'var(--surf2)',
                color: userTabs.includes(t.id) ? 'var(--accent)' : 'var(--muted)',
                borderColor: userTabs.includes(t.id) ? 'rgba(245,166,35,.4)' : 'var(--border)',
              }}>
                {userTabs.includes(t.id) ? '✓ ' : ''}{t.label}
              </div>
            ))}
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <button className="btn btn-primary btn-sm" onClick={saveTabs}>Yadda saxla</button>
            <button className="btn btn-ghost btn-sm" onClick={()=>setTabsUser(null)}>Ləğv et</button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="loading"><div className="spinner"/></div>
      ) : (
        <div style={{ background:'var(--surface)', border:'1px solid var(--border)',
          borderRadius:13, overflow:'hidden' }}>
          {users.map((u, idx) => (
            <div key={u.id} style={{
              display:'flex', alignItems:'center', gap:14, padding:'14px 18px',
              borderBottom: idx < users.length-1 ? '1px solid var(--border)' : 'none',
            }}>
              <div style={{ width:40, height:40, borderRadius:'50%', flexShrink:0,
                background: u.role==='admin'
                  ? 'linear-gradient(135deg,#f5a623,#e8965a)'
                  : 'linear-gradient(135deg,#38bdf8,#6366f1)',
                display:'flex', alignItems:'center', justifyContent:'center', fontSize:18 }}>
                {u.role==='admin' ? '👑' : '👤'}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:14, fontWeight:700 }}>{u.name}</div>
                <div style={{ fontSize:12, color:'var(--muted)', marginTop:2 }}>{u.email}</div>
              </div>
              <span style={{
                padding:'3px 10px', borderRadius:20, fontSize:11, fontWeight:700,
                background: u.role==='admin' ? 'rgba(245,166,35,.12)' : 'rgba(56,189,248,.12)',
                color: u.role==='admin' ? 'var(--accent)' : '#38bdf8',
                border: `1px solid ${u.role==='admin' ? 'rgba(245,166,35,.3)' : 'rgba(56,189,248,.3)'}`,
              }}>{ROLE_LABEL[u.role]||u.role}</span>
              <div style={{ display:'flex', gap:6 }}>
                {u.role === 'worker' && (
                  <button className="btn btn-ghost btn-sm" onClick={()=>openTabs(u)}
                    title="Tab icazələri">🗂</button>
                )}
                <button className="btn btn-ghost btn-sm" onClick={()=>openEdit(u)}>✏</button>
                {u.role !== 'admin' && (
                  <button className="btn btn-ghost btn-sm" style={{color:'var(--red)'}}
                    onClick={()=>del(u.id)}>🗑</button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  )
}
