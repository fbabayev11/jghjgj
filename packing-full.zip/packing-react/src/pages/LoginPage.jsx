import { useState } from 'react'
import { API } from '../config'

export default function LoginPage({ onLogin }) {
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr]           = useState('')
  const [loading, setLoading]   = useState(false)

  async function submit() {
    if (!email || !password) { setErr('Hər iki sahəni doldurun'); return }
    setErr(''); setLoading(true)
    try {
      const r = await fetch(`${API}/login`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim().toLowerCase(), password })
      })
      const d = await r.json()
      if (!r.ok) { setErr(d.detail || 'Xəta'); return }
      localStorage.setItem('auth_token', d.token)
      localStorage.setItem('auth_user', JSON.stringify(d.user))
      onLogin(d.user, d.token)
    } catch { setErr('Server cavab vermir') }
    finally { setLoading(false) }
  }

  return (
    <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center',
      background:'var(--bg)', padding:20 }}>
      <div style={{ background:'var(--surface)', border:'1px solid var(--border)', borderRadius:18,
        padding:36, width:'100%', maxWidth:400 }}>
        <div style={{ textAlign:'center', marginBottom:28 }}>
          <div style={{ width:56, height:56, borderRadius:14, margin:'0 auto 14px',
            background:'linear-gradient(135deg,#f5a623,#e8965a)',
            display:'flex', alignItems:'center', justifyContent:'center', fontSize:28 }}>📦</div>
          <div style={{ fontSize:22, fontWeight:800 }}>Qablaşdırma</div>
          <div style={{ fontSize:13, color:'var(--muted)', marginTop:6 }}>Hesabınıza daxil olun</div>
        </div>

        <div className="field">
          <label>Email</label>
          <input type="email" value={email} onChange={e=>setEmail(e.target.value)}
            placeholder="admin@packing.app"
            onKeyDown={e=>e.key==='Enter'&&submit()} />
        </div>
        <div className="field">
          <label>Şifrə</label>
          <input type="password" value={password} onChange={e=>setPassword(e.target.value)}
            placeholder="••••••••"
            onKeyDown={e=>e.key==='Enter'&&submit()} />
        </div>

        {err && <div className="error-bar" style={{marginBottom:14}}>{err}</div>}

        <button className="btn btn-primary" onClick={submit} disabled={loading}
          style={{ width:'100%', marginTop:4, padding:14, fontSize:15 }}>
          {loading ? 'Giriş edilir...' : 'Daxil ol'}
        </button>
      </div>
    </div>
  )
}
