import { useState, useEffect, useMemo } from 'react'
import { API } from './config'
import LoginPage from './pages/LoginPage'
import ConfigPage from './pages/ConfigPage'
import OrdersPage from './pages/OrdersPage'
import ArchivePage from './pages/ArchivePage'
import ImagesPage from './pages/ImagesPage'
import StatsPage from './pages/StatsPage'
import ManualOrdersPage from './pages/ManualOrdersPage'
import AllOrdersPage from './pages/AllOrdersPage'
import UsersPage from './pages/UsersPage'

const ALL_TABS = [
  { id:'orders',    label:'Sifarişlər',        icon:'📦' },
  { id:'manual',    label:'Manual Sifarişlər', icon:'💬' },
  { id:'allorders', label:'Bütün Sifarişlər',  icon:'🗂' },
  { id:'stats',     label:'Statistika',        icon:'📊' },
  { id:'images',    label:'Şəkillər',          icon:'🖼' },
  { id:'settings',  label:'API Key',           icon:'🔑' },
  { id:'users',     label:'İstifadəçilər',     icon:'👥' },
]

const ADMIN_TABS = ALL_TABS.map(t => t.id)
const DEFAULT_WORKER_TABS = ['orders', 'manual']

export default function App() {
  const [user, setUser]   = useState(() => {
    try { return JSON.parse(localStorage.getItem('auth_user')) } catch { return null }
  })
  const [token, setToken] = useState(() => localStorage.getItem('auth_token') || '')
  const [tab, setTab]     = useState('orders')
  const [allowedTabs, setAllowedTabs] = useState(ADMIN_TABS)
  const [shopName, setShopName]       = useState('')
  const [orders, setOrders]           = useState([])

  // Token yoxla
  useEffect(() => {
    if (!token) return
    fetch(`${API}/me`, { headers:{ Authorization:`Bearer ${token}` } })
      .then(r => { if (!r.ok) logout(); return r.json() })
      .then(u => { setUser(u); loadUserTabs(u) })
      .catch(() => {})
  }, [])

  // Config yüklə
  useEffect(() => {
    if (!token) return
    fetch(`${API}/config`, { headers:{ Authorization:`Bearer ${token}` } })
      .then(r => r.json())
      .then(d => { if (d.configured) setShopName(d.shop_name || d.shop) })
      .catch(() => {})
  }, [token])

  // Keep-alive
  useEffect(() => {
    const id = setInterval(() => fetch(`${API}/ping`).catch(()=>{}), 13*60*1000)
    return () => clearInterval(id)
  }, [])

  async function loadUserTabs(u) {
    if (u.role === 'admin') { setAllowedTabs(ADMIN_TABS); return }
    try {
      const r = await fetch(`${API}/user-tabs/${u.id}`,
        { headers:{ Authorization:`Bearer ${token}` } })
      const d = await r.json()
      setAllowedTabs(d.tabs?.length ? d.tabs : DEFAULT_WORKER_TABS)
    } catch { setAllowedTabs(DEFAULT_WORKER_TABS) }
  }

  function onLogin(u, t) {
    setUser(u); setToken(t)
    if (u.role === 'admin') setAllowedTabs(ADMIN_TABS)
    else loadUserTabs(u)
  }

  function logout() {
    localStorage.removeItem('auth_token')
    localStorage.removeItem('auth_user')
    setUser(null); setToken('')
  }

  const productNames = useMemo(() => {
    const s = new Set()
    orders.forEach(o => o.items?.forEach(i => {
      if (i.is_custom_box) (i.box_contents||[]).forEach(c => { if(c.name) s.add(c.name) })
      else if (i.name) s.add(i.name)
    }))
    return [...s].sort()
  }, [orders])

  if (!user || !token) return <LoginPage onLogin={onLogin} />

  const visibleTabs = ALL_TABS.filter(t => allowedTabs.includes(t.id))

  return (
    <>
      <header>
        <div className="logo">
          <div className="logo-icon">📦</div>
          <span className="logo-text">Qablaşdırma</span>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <span className="shop-badge" style={{ display:'flex', alignItems:'center', gap:6 }}>
            {user.role === 'admin' ? '👑' : '👤'} {user.name}
          </span>
          <button className="btn btn-ghost btn-sm" onClick={logout}>Çıxış</button>
        </div>
      </header>

      <div className="tabs">
        {visibleTabs.map(t => (
          <button key={t.id} className={`tab${tab===t.id?' active':''}`} onClick={() => setTab(t.id)}>
            <span className="tab-icon">{t.icon}</span>
            <span className="tab-label">{t.label}</span>
          </button>
        ))}
      </div>

      <main>
        {tab === 'orders'    && <OrdersPage token={token} />}
        {tab === 'manual'    && <ManualOrdersPage />}
        {tab === 'allorders' && <AllOrdersPage token={token} />}
        {tab === 'stats'     && <StatsPage token={token} />}
        {tab === 'images'    && <ImagesPage productNames={productNames} token={token} />}
        {tab === 'settings'  && <ConfigPage token={token}
          onSave={name => { setShopName(name); setTab('orders') }} />}
        {tab === 'users'     && <UsersPage token={token} />}
      </main>
    </>
  )
}
